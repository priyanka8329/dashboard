<?php

namespace Faker\Provider\en_NG;

class Internet extends \Faker\Provider\Internet
{
    protected static $tld = ['com.ng', 'com', 'ng', 'net', 'edu.ng', 'org', 'gov.ng', 'org.ng', 'biz', 'co'];
}
